﻿namespace SimpleK8.Core;

public enum PodStatus
{
	Pending,
	Running,
	Succeeded,
	Failed
}