﻿namespace SimpleK8.Core;

public enum ContainerStatus
{
	Created, 
	Running,
	Stopped,
	Failed
}